﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work12_23._06._19_
{
    internal class Card
    {
    }
}
