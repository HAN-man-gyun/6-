﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work12_23._06._19_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //배열의 초기화 
            string[] nums = new string[13] { "A", "2", "3", "4", "5", "6", "7", "8", "9","10","J","Q","K" };//int형 배열과 
            string[] patterns = new string[4] { "♠", "◈", "♥", "♣" };// string형 배열을 선언하고
            List<Cards> Deck = new List<Cards>();
            List<Cards> computerDeck = new List<Cards>();
            List<Cards> playerDeck = new List<Cards>();
            Random rand = new Random();
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    Cards card = new Cards();
                    card.pattern=patterns[i];
                    card.num=nums[j];
                    Deck.Add(card);
                }
            }

            //전체 배열 출력문
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    Console.Write("{0,3},{1,3}", Deck[i*13+j].pattern, Deck[i*13+j].num);
                }
                Console.WriteLine();
            }

            //
            for (int i = 0; i < 7; i++)
            {
                int index = rand.Next(0, Deck.Count);
                Cards card = new Cards();
                card.pattern = Deck[index].pattern;
                card.num = Deck[index].num;
                computerDeck.Add(card);
                Deck.Remove(Deck[index]);
            }
            for(int j = 0; j < 5; j++)
            {
                int index = rand.Next(0, Deck.Count);
                Cards card = new Cards();
                card.pattern = Deck[index].pattern;
                card.num = Deck[index].num;
                playerDeck.Add(card);
                Deck.Remove(Deck[index]);
            }

            
            Console.WriteLine("컴퓨터가 뽑은 카드들");
            for(int i=0; i<7; i++)
            {
                Console.Write("{0,3} {1,3}", computerDeck[i].pattern, computerDeck[i].num);
            }
            Console.WriteLine();
            Console.WriteLine("플레이어가 뽑은 카드들");
            for (int i = 0; i < 5; i++)
            {
                Console.Write("{0,3} {1,3}", playerDeck[i].pattern, playerDeck[i].num);
            }
            Console.WriteLine();


            //리롤기능
            Console.WriteLine("리롤하고자하는 카드들의 인덱스를 입력하세요");
            int input = int.Parse(Console.ReadLine());
            int input2 = int.Parse(Console.ReadLine());

            playerDeck.Remove(playerDeck[input]);
            if (input < input2)
            {
                playerDeck.Remove(playerDeck[input2 - 1]);
            }
            else
            {
                playerDeck.Remove(playerDeck[input]);
            }


            //리롤후 셔플 
            for (int j = 0; j < 2; j++)
            {
                int index = rand.Next(0, Deck.Count);
                Cards card = new Cards();
                card.pattern = Deck[index].pattern;
                card.num = Deck[index].num;
                playerDeck.Add(card);
                Deck.Remove(Deck[index]);
            }

            Console.WriteLine("컴퓨터가 뽑은 카드들");
            for (int i = 0; i < 7; i++)
            {
                Console.Write("{0,3} {1,3}", computerDeck[i].pattern, computerDeck[i].num);
            }
            Console.WriteLine();
            Console.WriteLine("플레이어가 뽑은 카드들");
            for (int i = 0; i < 5; i++)
            {
                Console.Write("{0,3} {1,3}", playerDeck[i].pattern, playerDeck[i].num);
            }
            Console.WriteLine();
/*

            bool RoyalStraightFlush(List <Cards> player)
            {
                List<string> hand = new List<string> { "10","J","Q","K","A"};
                int count = 0;
                for(int i = 0;i<4; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        if ((player[0].pattern == player[1].pattern) && (player[1].pattern == player[2].pattern)
                            && (player[2].pattern == player[3].pattern))
                        {
                            player[j] == ;
                        }
                    }
                }
                return true;
            }
*/
        }
    }
}
